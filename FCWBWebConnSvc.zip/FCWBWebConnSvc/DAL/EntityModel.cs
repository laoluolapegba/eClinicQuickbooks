﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FCQBWebConnAPI.DAL
{
    public class EntityModel
    {
    }
}